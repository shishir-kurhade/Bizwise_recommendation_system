#'TopCompetitors
#'
#' \code{reg} Shows Total checkins per day for particular business.
#'
#' @param cat The category of business
#' @param cty The city.
#' @param n How many results to get
#'
#' @return A Bar plot showing checkins for top n values of particular Business \code{reg}.
#'
#'
#' @export
#' @importFrom ggplot2 ggplot geom_col aes xlab ylab ggtitle element_text theme
#' @importFrom dplyr transmute filter %>%
#' @importFrom utils head globalVariables
  

TopCompetitors<- function(cat,cty,n)
{
  check1<-transmute(checkin,business_id=business_id,Totalvisits=rowSums(checkin[, -22],na.rm = TRUE))
  Business<-merge(check1,business, by='business_id')
  
  #Businesses for category food
  cat_business<-filter(Business,category== cat)
  
  #Removing rows with all NAs
  cat_business<-cat_business[, colSums(is.na(cat_business)) != nrow(cat_business)]
  
  
  #subsetting
  cat_business<-select(cat_business,business_id,Totalvisits,city,category,name,stars)
  
  filt_Business<-filter(cat_business,city == cty)
  TopBusiness<-arrange(filt_Business,desc(stars),desc(Totalvisits))
  TopBusiness<-head(TopBusiness,n=n)
  
  
  
  TopBusiness%>%
    ggplot(aes(x=name)) + geom_col(aes( y=Totalvisits) , position = "dodge",fill="Dark blue") +xlab('Businesses')+ylab('Total no. of checkins per day')+ggtitle("Performance by Top Competitors")+theme(
      axis.text.x = element_text(angle = 15, hjust = 1)
    ) 
  
  
}
