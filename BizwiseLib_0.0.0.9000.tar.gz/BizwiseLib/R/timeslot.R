#'TimeSlot function
#'
#' \code{reg} This function plots total number of checkins as per time slots for different days of week, to help people understand the rush hours for each business of particular rating.
#'
#' @param cty The city.
#' @param StarRating The star rating of business

#'
#' @return The distribution of time slots as per the days \code{reg}.
#'
#' @export
#' @importFrom ggplot2 ggplot geom_col scale_fill_brewer ggtitle theme element_text
#' @importFrom dplyr transmute filter
#' @importFrom tidyr gather separate drop_na
#' @importFrom graphics text stars 


timeslot<-function(cty,StarRating)
{
  stars<-transmute(business,business_id=business_id,stars=stars)
  business1<-transmute(business,business_id=business_id,city=city)
  checkin_1<-merge(checkin,business1, by='business_id')
  checkin_1<-merge(checkin_1,stars, by='business_id')
  
  checkin_1<-filter(checkin_1,city==cty & stars==StarRating)
  checkin_1 <- gather(checkin_1,Time,Freq,-business_id,na.rm = TRUE)
  checkin_1 <- separate(checkin_1, Time, c("T1","DayTime"),sep=5)
  
  checkin_1<- transmute(checkin_1,Freq=Freq,business_id=business_id,DayTime=DayTime)
  checkin_1 <- separate(checkin_1, DayTime, c("Day","Time"),sep="\\.")
  checkin_1<-transmute(checkin_1,Day=factor(Day,levels=c("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday")),Time=Time,Freq=Freq)
  
  
  checkin4 <-summarise(group_by(checkin_1, Day,Time),Freq=n() )
  checkin4<-checkin4 %>% drop_na()
  
  
  
  checkin4%>%
    ggplot() + geom_col(aes(x=factor(Time,levels=c("9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","0","1","2","3","4","5","6","7","8")), y=Freq, fill= Day) , position = 'stack')+ scale_fill_brewer(palette="Set3")+xlab('Time Slots')+ylab('Count per day')+ggtitle("Checkins on Particular Day and Time.")+theme(
      axis.text.x = element_text(angle = 45, hjust = 1))
  
}
