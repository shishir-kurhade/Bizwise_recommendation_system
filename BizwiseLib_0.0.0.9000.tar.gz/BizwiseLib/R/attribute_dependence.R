#'attribute_dependence
#'
#' \code{reg} plots dependence of map on attributes for different cities and categories.
#'

#' @param cty The city.
#' @param cat The category of business
#' @param attribute Attributes of different businesses
#'
#' @return Displays the businesses based on star ratings  \code{reg}.
#'
#' @export
#' @importFrom ggplot2 ggplot facet_wrap geom_bar
#' @importFrom dplyr filter %>%
#' @importFrom utils globalVariables



attribute_dependence <- function(cty, cat, attribute){
  
  business <-  business %>%
    mutate(category = if_else(
      grepl(pattern = 'Restaurants',
            x = business$categories) == TRUE,
      'Restaurant',
      if_else(
        grepl(pattern = 'Nightlife', x = business$categories) == TRUE,
        'Nightlife',
        if_else(
          grepl(pattern = 'Shopping', x = business$categories) == TRUE,
          'Shopping',
          if_else(
            grepl(pattern = 'Food', x = business$categories) == TRUE,
            'Food',
            if_else(
              grepl(pattern = 'Health & Medical', x = business$categories) == TRUE,
              'Health & Medical',
              if_else(
                grepl(pattern = 'Beauty & Spas', x = business$categories) == TRUE,
                'Beauty & Spas',
                if_else(
                  grepl(pattern = 'Home Services', x = business$categories) == TRUE,
                  'Home Services',
                  if_else(
                    grepl(pattern = 'Local Services', x = business$categories) == TRUE,
                    'Local Services',
                    if_else(
                      grepl(pattern = 'Event Planning & Services', x = business$categories) ==
                        TRUE,
                      'Event Planning & Services',
                      if_else(
                        grepl(pattern = 'Arts & Entertainment', x = business$categories) == TRUE,
                        'Arts & Entertainment',
                        if_else(
                          grepl(pattern = 'Active Life', x = business$categories) == TRUE,
                          'Active Life',
                          if_else(
                            grepl(pattern = 'Professiol Services', x = business$categories) == TRUE,
                            'Professiol Services',
                            if_else(
                              grepl(pattern = 'Automotive', x = business$categories) == TRUE,
                              'Automotive',
                              if_else(
                                grepl(pattern = 'Hotel & Travel', x = business$categories) == TRUE,
                                'Hotel & Travel',
                                if_else(
                                  grepl(pattern = 'Education', x = business$categories) == TRUE,
                                  'Education',
                                  if_else(
                                    grepl(pattern = 'Real Estate', x = business$categories) == TRUE,
                                    'Real Estate',
                                    if_else(
                                      grepl(pattern = 'Pets', x = business$categories) == TRUE,
                                      'Pets',
                                      if_else(
                                        grepl(pattern = 'Financial Services', x = business$categories) == TRUE,
                                        'Financial Services',
                                        if_else(
                                          grepl(pattern = 'Local Flavor', x = business$categories) == TRUE,
                                          'Local Flavor',
                                          if_else(
                                            grepl(pattern = 'Public Services & Government', x = business$categories) ==
                                              TRUE,
                                            'Public Services & Government',
                                            if_else(
                                              grepl(pattern = 'Mass Media', x = business$categories) == TRUE,
                                              'Mass Media',
                                              if_else(
                                                grepl(pattern = 'Religious Organization', x = business$categories) == TRUE,
                                                'Religious Organization',
                                                'NA'
                                              )
                                            )
                                          )
                                        )
                                      )
                                    )
                                  )
                                )
                              )
                            )
                          )
                        )
                      )
                    )
                  )
                )
              )
            )
          )
        )
      )
    ))
  
  filtered_business <- filter(business, tolower(city) == tolower(cty) & tolower(business$category) == tolower(cat))
  filtered_business <- filter(filtered_business, !is.na(filtered_business[[attribute]]))
  
  
  graph <- ggplot(filtered_business, aes_string(attribute, fill=attribute)) + geom_bar() 
  
  
  final_graph <- graph + facet_wrap(~ stars) + labs(x = attribute, y = "Number of Businesses", title = "Businesses Based On Star Ratings", fill=attribute)
  
  return (final_graph)
}

