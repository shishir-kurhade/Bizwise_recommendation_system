#' fun_map
#'
#' \code{reg} Plotting businesses on the basis of price range category and location.

#' @param in_city The city.
#' @param in_category The category of business
#' @param star_rating The star rating of business
#' @param top_no How many results to get
#'
#' @return A map with businesses plot on basis of user input \code{reg}.
#'
#'
#' @export
#' @importFrom ggmap qmap
#' @importFrom ggplot2 ggplot guides geom_point guide_legend

#' @importFrom dplyr filter arrange desc top_n

fun_map <- function(in_city, in_category, star_rating, top_no)
{
  result <- filter(business, city == in_city,
                   category == in_category,
                   stars == star_rating) %>%
    arrange(desc(review_count)) %>%
    top_n(top_no, business_id)
  
  Map1<-qmap(in_city, zoom = 11)
  
  Map1 +
    geom_point(data = result,
               aes(x = longitude,
                   y = latitude,
                   colour = factor(attributes.RestaurantsPriceRange2)), size=5) +
    guides(colour = guide_legend(title = 'Price Range'))
  
}
