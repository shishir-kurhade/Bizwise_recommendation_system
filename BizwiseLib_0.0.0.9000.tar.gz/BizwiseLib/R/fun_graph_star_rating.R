
#'fun_graph_star_rating
#'
#' \code{reg} Bar plot showing number of business for each star rating in a city, in a particular category.
#'
#' @param in_city The city.
#' @param in_category The category of business
#'
#' @return An object of class which gives us the plot \code{reg}.
#'
#' @export
#' @importFrom ggplot2 ggplot geom_bar
#' @importFrom dplyr mutate filter


fun_graph_star_rating <- function(in_city, in_category)
{
  business %>%
    mutate(stars = as.factor(stars)) %>%
    filter(city == in_city, category == in_category) %>%
    ggplot(aes(x = stars)) + geom_bar(aes(fill = stars))
}

#star-wise how many restaurants are there in given city
#The function ntakes as inputs the city and category from the Shiny UI
#The output displays a graph showing how many business for each star rating in the city
