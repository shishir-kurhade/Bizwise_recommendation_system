#'compute_wordcloud
#'
#' \code{reg} The function computes a word cloud of negative reviews for top businesses in a particular city for a category depending on the user. The user may input the frequency of words and number of words to be displayed in the word cloud.
#'
#' @param city_input The city.
#' @param star_input The star rating of business
#' @param category_input The category of business
#' @param word_freq Frequency of Words
#' @param number_word numberof words to be displayed on word cloud
#' @param top_competitors Number of top competitors
#'
#' @return  Word cloud for negative reviews \code{reg}.
#'
#'
#' @export


#' @importFrom wordcloud wordcloud 
#' @importFrom dplyr transmute filter select arrange anti_join
#' @importFrom tm tm_map Corpus TermDocumentMatrix content_transformer VectorSource
#' @importFrom RColorBrewer brewer.pal
#' @importFrom tidytext unnest_tokens get_sentiments
#' @importFrom utils head



compute_wordcloud <- function(city_input, star_input, category_input,word_freq,number_word,top_competitors)
{
 
   business <-  business %>%
    mutate(category = if_else(
      grepl(pattern = 'Restaurants',
            x = business$categories) == TRUE,
      'Restaurant',
      if_else(
        grepl(pattern = 'Nightlife', x = business$categories) == TRUE,
        'Nightlife',
        if_else(
          grepl(pattern = 'Shopping', x = business$categories) == TRUE,
          'Shopping',
          if_else(
            grepl(pattern = 'Food', x = business$categories) == TRUE,
            'Food',
            if_else(
              grepl(pattern = 'Health & Medical', x = business$categories) == TRUE,
              'Health & Medical',
              if_else(
                grepl(pattern = 'Beauty & Spas', x = business$categories) == TRUE,
                'Beauty & Spas',
                if_else(
                  grepl(pattern = 'Home Services', x = business$categories) == TRUE,
                  'Home Services',
                  if_else(
                    grepl(pattern = 'Local Services', x = business$categories) == TRUE,
                    'Local Services',
                    if_else(
                      grepl(pattern = 'Event Planning & Services', x = business$categories) ==
                        TRUE,
                      'Event Planning & Services',
                      if_else(
                        grepl(pattern = 'Arts & Entertainment', x = business$categories) == TRUE,
                        'Arts & Entertainment',
                        if_else(
                          grepl(pattern = 'Active Life', x = business$categories) == TRUE,
                          'Active Life',
                          if_else(
                            grepl(pattern = 'Professiol Services', x = business$categories) == TRUE,
                            'Professiol Services',
                            if_else(
                              grepl(pattern = 'Automotive', x = business$categories) == TRUE,
                              'Automotive',
                              if_else(
                                grepl(pattern = 'Hotel & Travel', x = business$categories) == TRUE,
                                'Hotel & Travel',
                                if_else(
                                  grepl(pattern = 'Education', x = business$categories) == TRUE,
                                  'Education',
                                  if_else(
                                    grepl(pattern = 'Real Estate', x = business$categories) == TRUE,
                                    'Real Estate',
                                    if_else(
                                      grepl(pattern = 'Pets', x = business$categories) == TRUE,
                                      'Pets',
                                      if_else(
                                        grepl(pattern = 'Financial Services', x = business$categories) == TRUE,
                                        'Financial Services',
                                        if_else(
                                          grepl(pattern = 'Local Flavor', x = business$categories) == TRUE,
                                          'Local Flavor',
                                          if_else(
                                            grepl(pattern = 'Public Services & Government', x = business$categories) ==
                                              TRUE,
                                            'Public Services & Government',
                                            if_else(
                                              grepl(pattern = 'Mass Media', x = business$categories) == TRUE,
                                              'Mass Media',
                                              if_else(
                                                grepl(pattern = 'Religious Organization', x = business$categories) == TRUE,
                                                'Religious Organization',
                                                'NA'
                                              )
                                            )
                                          )
                                        )
                                      )
                                    )
                                  )
                                )
                              )
                            )
                          )
                        )
                      )
                    )
                  )
                )
              )
            )
          )
        )
      )
    ))
  
  check1 <-
    transmute(checkin,
              business_id = business_id,
              Totalvisits = rowSums(checkin[,-22], na.rm = TRUE))
  Business <- merge(check1, business, by = 'business_id')
  
  #Businesses for category food
  business_cat <-
    filter(Business,
           category == category_input,
           city == city_input,
           stars == star_input)
  
  #Removing rows with all NAs
  FB1 <-
    business_cat[, colSums(is.na(business_cat)) != nrow(business_cat)]
  
  
  #subsetting
  FB1 <-
    select(
      FB1,
      business_id,
      Totalvisits,
      city,
      category,
      name,
      stars
    )
  
  filt_Business <- filter(FB1, city == city_input)
  a <- arrange(filt_Business,desc(Totalvisits))
  a <- head(a, n = top_competitors)
  
  
  list_of_bids <-
    business_cat$business_id 
  review1 <-
    review %>% transmute(
      business_id = business_id,
      text = text,
      useful = useful,
      review_id = review_id,
      stars = stars
    ) %>% filter(business_id %in% list_of_bids)
  review1$text <- as.character(review1$text)
  
  review_words <- review1 %>%
    unnest_tokens(word, text, token = "words")
  
  review_words <- review_words %>%
    anti_join(stop_words)
  
  afinn <- get_sentiments("afinn")
  
  d <- review_words %>%
    inner_join(afinn, by = "word")
  
  negative_reviews_data <-
    d %>% group_by(business_id, review_id) %>% summarise(total_score = sum(score)) %>%
    filter(total_score < 0)
  
  review_cus <-
    review %>% filter(review_id %in% negative_reviews_data$review_id)
  docs <- Corpus(VectorSource(review_cus$text))
  #inspect(docs)
  #Converting to lower case, removing stopwords, punctuation and numbers
  docs <- tm_map(docs, tolower)
  #docs <- tm_map(docs, removeWords, c(stopwords("english"),"s","ve"))
  docs <- tm_map(docs, PlainTextDocument)
  docs <- tm_map(docs, removeWords, c(city_input))
  docs <- tm_map(docs, content_transformer(tolower))
  # Remove numbers
  docs <- tm_map(docs, removeNumbers)
  # Remove english common stopwords
  docs <- tm_map(docs, removeWords, stopwords("english"))
  # Remove punctuations
  docs <- tm_map(docs, removePunctuation)
  # Eliminate extra white spaces
  docs <- tm_map(docs, stripWhitespace)
  
  
  dtm <- TermDocumentMatrix(docs)
  m <- as.matrix(dtm)
  v <- sort(rowSums(m), decreasing = TRUE)
  d <- data.frame(word = names(v), freq = v)
  #head(d, 10)
  
  set.seed(1234)
  wordcloud(
    words = d$word,
    freq = d$freq,
    min.freq = word_freq,
    max.words = number_word,
    random.order = FALSE,
    rot.per = 0.35,
    colors = brewer.pal(8, "Dark2"
    )
  )
}


